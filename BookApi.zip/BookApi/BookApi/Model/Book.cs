﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace BookApi.Model
{
    public class Book
    {

        [Key]
        public int Book_ID { get; set; }

        public string Display_ID { get; set; }

        public string Creator { get; set; }

        public DateTime? Creation_Time { get; set; }

        public DateTime? Edit_Time { get; set; }

        public string Status { get; set; }

        [Required]
        public string BookName { get; set; }

        [Required]
        public string Category { get; set; }

        public double Price { get; set; }

        [Required]
        public string Author { get; set; }

        public DateTime? Date_Time { get; set; }

        public string Pick_Up_Point { get; set; }

        public string Destination { get; set; }

        public decimal Current_Location_Latitude { get; set; }

        public decimal Current_Location_Longitude { get; set; }
    }
}
